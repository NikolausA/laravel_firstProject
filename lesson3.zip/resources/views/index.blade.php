@extends('layouts.main')

@section('title')
@parentГлавная
@endsection

@section('menu')
    @include('menu')
@endsection

@section('content')
    <h1>Главная страница сайта</h1>
@endsection
