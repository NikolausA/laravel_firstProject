@extends('layouts.main')

@section('title')
    @parentСтраница 2
@endsection

@section('menu')
    @include('admin.menu')
@endsection

@section('content')
    <h2>Страница 2</h2>
@endsection
