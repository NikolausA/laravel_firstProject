@extends('layouts.main')

@section('title')
    @parentСтраница 1
@endsection

@section('menu')
    @include('admin.menu')
@endsection

@section('content')
    <h2>Страница 1</h2>
@endsection


