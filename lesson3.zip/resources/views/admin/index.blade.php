@extends('layouts.main')

@section('title')
    @parentАдминка
@endsection

@section('menu')
    @include('admin.menu')
@endsection

@section('content')
    <h2>Админка</h2>
@endsection

