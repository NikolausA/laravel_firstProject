

<?php $__env->startSection('title', 'Создание новости'); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h2>Добавление новости</h2>
        <?php echo csrf_field(); ?>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">Добавление новости</div>
                        <div class="card-body">
                            <form enctype="multipart/form-data" method="POST" action="<?php echo e(route('admin.create')); ?>">
                                <?php echo csrf_field(); ?>

                                <div class="form-group row">
                                    <label for="newsTitle" class="col-md-4 col-form-label text-md-right">Заголовок новости</label>
                                    <div class="col-md-6">
                                        <input id="newsTitle" type="text" class="form-control" name="title" value="<?php echo e(old('title')); ?>" >
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="newsCategory" class="col-md-4 col-form-label text-md-right">Категория новости</label>
                                    <div class="col-md-6">
                                        <select class="form-control" name="category" id="newsCategory">
                                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option <?php if($item['id'] == old('name')): ?> selected <?php endif; ?> value="<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <option value="0" selected>Нет категории</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="newsText" class="col-md-4 col-form-label text-md-right">Текст новости</label>
                                    <div class="col-md-6">
                                        <textarea class="form-control" name="text" id="newsText" cols="30" rows="10"><?php echo e(old('text')); ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="image" class="col-md-4 col-form-label text-md-right"></label>
                                    <div class="col-md-6">
                                        <input type="file" name="image" id="image">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-md-6 offset-md-4">
                                        <div class="form-check">
                                            <input <?php if(old('isPrivate') === "1"): ?> checked <?php endif; ?> class="form-check-input" type="checkbox" id="newsPrivate" name="isPrivate" value="1">
                                            <label class="form-check-label" for="newsPrivate">
                                                Новость приватная
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row mb-0">
                                    <div class="col-md-8 offset-md-4">
                                        <button type="submit" class="btn btn-primary">
                                            Добавить новость
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </for
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/firstproject/resources/views/admin/create.blade.php ENDPATH**/ ?>