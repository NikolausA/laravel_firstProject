<?php include "menu.blade.php"; ?>
<h1>О сайте</h1>
